#My HW3 Self Reflection

Q1: Confidence Check: How confident do you feel about HTML after two weeks in WRIT40363? What specific skills feel solid, and what still feels challenging?

A1: In all honesty, this course is entirely out of my comfort zone. I feel both terrified -- as I feel I could easily get lost -- and eager for the opportunity to expand as a student. I feel solid following the instructions listed in D2L, but is there is any variation I am most likely going to have some errors in my content. This being said, I feel very fortunate ti have several familiar faces in the course in case I run into questions or need someone with an increased level of understanding to support me.

Q2: Learning Curve: Describe your experience learning Git and GitHub. What surprised you about version control? What part was more/less difficult than expected?

A2: I would say my experience with learning Git and GitHub was relatively consistent with that of my peers. I had a few hiccups where my platform did not want to create a document labeled 'WRIT40363-Portfolio', but I was able to quickly shift, adding my last name to the document name. As for the diffivulty level, it felt relatively consistent with my expectations. 

Q3: Problem-Solving Growth: When you encountered problems this week (code not working, Git confusion, etc.), how did you approach solving them? How has this changed since Week 1?

A3: In the afformentioned response to question 1, I shared that I am fortunate enough to have several familiar faces in the class although I am not familiar with the department nor subject. When encountering problems, this relationships have been extremely helpful. My approach has changed to rereading instructions, only asking when I feel completely lost. This week, I only asked one question of a peer (relating more to instructions than the platform itself) which an improvement from the prior week. 

Q4: Professional Mindset: How do you feel about the transition from "just making web pages" to "developing professionally with semantic HTML and version control"? What excites or concerns you?

A4: I feel this question does not exactly emmulate how I am feeling in this moment. Honestly, I do not see this was "just making web pages" -- rather this feels like a skill that translates beyond the classroom. This excites me because this is so new to me, but this also concerns me as it suggests there are several gaps in my liberal arts education. When chatting with Dean Sonja Watson about areas of improvement in AddRan College, I shared that I felt we lacked some technical skills such web page creation, Excel usage, and coding. I think this theme overall is concerning. 

Q5: Week 2 Reflection: What's your biggest "aha moment" or breakthrough from this week? What concept finally "clicked" for you?

A5: When comparing our current projects to Dr. Rode's site, I think my biggest "aha moment" was the fact that these skills are very foundational for something much larger. While this may reveal my naivete, this truly is a breakthrough realization for me. As an economics major, I feel "supply and demand" graphs and "Cobb-Douglas Production Functions" are not as applicable outside the classroom as technical skills provided in this course. 

Q6: Looking Forward: Based on your experience so far, what aspect of web development are you most curious about or nervous about learning next?

A6: I suppose I am most looking forward to seeing the final product. Again, this may be a naive answer, but I have no idea what steps will unfold as the course progresses, so I am very eager to see how much I learn about web development over the course of 16 weeks.

Q7: Support and Resources: What's been most helpful for your learning so far (class discussions, hands-on practice, online resources, classmates)? What additional support might you need moving forward?

A7: So far, the most helpful and accessible resoruce has been our in-class instruction and practice. I am an auditory learner so being able to see, hear, and do actions all at once is extremely beneficial to my overall performance and understanding. As for additional support, I really appreciate the level of detail included in the D2L assignments and feel this is a great resource for outside of class. 

