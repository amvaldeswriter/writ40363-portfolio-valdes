Project description:
Personal Website Foundation Course: WRIT 40363 - Intro to Web Applications
Lab: 02 - File Organization & Web Development Concepts
Files included:
- index.html: Homepage with introduction
- about.html: Detailed about page
- css/: Folder for future stylesheets
- images/: Folder for website images
 Notes: This project demonstrates proper file organization and multi-page HTML structure.